
 const FOOTER_CONTACT_INFO = {
  title: "Contact Us",
  links: [
    { label: "Contact Number", value: "123-456-7890" },
    { label: "Email Address", value: "info@shoppee.com" },
  ],
};

export default FOOTER_CONTACT_INFO